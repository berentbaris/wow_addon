----------------------------------------------------------------------
-- HardcoreClassesEnhanced — Requirements Panel
--
-- A persistent, dockable panel that shows the selected enhanced
-- class's full requirement list, with level-gated items greyed out
-- and currently-active items lit up.
--
-- Opens via:
--   * /hce panel  (toggle)
--   * /hce req    (toggle, alias)
--   * the draggable minimap button
--
-- Auto-refreshes on PLAYER_LEVEL_UP and when the selection changes.
--
-- Layout:
--   +------------------------------------------+
--   | Mountain King               [ pin ] [X]  |
--   |  Protection Warrior · lv 14 / 60         |
--   |------------------------------------------|
--   |  3 / 7 requirements active               |
--   |------------------------------------------|
--   |  EQUIPMENT                               |
--   |  [ACTIVE] Mace or axe                    |
--   |  [lv 5]   Shield                         |
--   |  [lv 50]  Flask trinkets                 |
--   |                                          |
--   |  CHALLENGES                              |
--   |  [ACTIVE] No professions                 |
--   |  [lv 20]  Homebound                      |
--   |      Can't leave home continent          |
--   |                                          |
--   |  COMPANION · PET · MOUNT                 |
--   |  ...                                     |
--   +------------------------------------------+
----------------------------------------------------------------------

HCE = HCE or {}

local Panel = {}
HCE.Panel   = Panel

----------------------------------------------------------------------
-- Constants / visual config
----------------------------------------------------------------------

local FRAME_WIDTH   = 320
local FRAME_HEIGHT  = 440
local ROW_HEIGHT    = 16
local SECTION_GAP   = 8
local PAD_X         = 14
local PAD_Y         = 10

local COLOR_ACTIVE   = { r = 0.30, g = 0.90, b = 0.35 }
local COLOR_INACTIVE = { r = 0.55, g = 0.55, b = 0.55 }
local COLOR_HEADER   = { r = 1.00, g = 0.78, b = 0.10 }
local COLOR_SUBTXT   = { r = 0.75, g = 0.75, b = 0.75 }
local COLOR_PASS     = { r = 0.30, g = 0.90, b = 0.35 }   -- green checkmark
local COLOR_FAIL     = { r = 1.00, g = 0.35, b = 0.30 }   -- red cross
local COLOR_UNCHK    = { r = 0.65, g = 0.65, b = 0.50 }   -- muted amber

local CLASS_COLORS = {
    WARRIOR = "c79c6e", ROGUE   = "fff569", MAGE    = "69ccf0",
    WARLOCK = "9482c9", PRIEST  = "ffffff", PALADIN = "f58cba",
    DRUID   = "ff7d0a", SHAMAN  = "0070de", HUNTER  = "abd473",
}

local function classColor(c)
    return CLASS_COLORS[c or ""] or "ffd100"
end

local function titleCase(s)
    if not s or s == "" then return "" end
    return s:sub(1, 1):upper() .. s:sub(2):lower()
end

----------------------------------------------------------------------
-- Global DB defaults for panel persistence
----------------------------------------------------------------------

local function db()
    HCE_GlobalDB = HCE_GlobalDB or {}
    HCE_GlobalDB.panel = HCE_GlobalDB.panel or {
        shown       = false,     -- visible on login if true
        locked      = false,     -- lock position (disables drag)
        point       = "CENTER",
        relPoint    = "CENTER",
        x           = 0,
        y           = 0,
        minimap     = { angle = 215, hide = false },
    }
    return HCE_GlobalDB.panel
end

----------------------------------------------------------------------
-- Main frame
----------------------------------------------------------------------

local frame          -- the panel itself
local contentFrame   -- child holding the row fontstrings (scroll child)
local scrollFrame
local rowPool = {}
local headerLabel, subLabel, countLabel
local pinButton
local closeButton

local function acquireRow(index)
    local row = rowPool[index]
    if row then return row end

    row = CreateFrame("Frame", nil, contentFrame)
    row:SetHeight(ROW_HEIGHT)
    row:SetPoint("LEFT", contentFrame, "LEFT", 0, 0)
    row:SetPoint("RIGHT", contentFrame, "RIGHT", 0, 0)
    row:EnableMouse(true)

    row.tag = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.tag:SetPoint("TOPLEFT", row, "TOPLEFT", 2, 0)
    row.tag:SetWidth(58)
    row.tag:SetJustifyH("LEFT")

    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    row.text:SetPoint("TOPLEFT", row.tag, "TOPRIGHT", 4, 0)
    row.text:SetPoint("RIGHT", row, "RIGHT", -2, 0)
    row.text:SetJustifyH("LEFT")
    row.text:SetWordWrap(true)

    -- Hover highlight for interactive rows (manually shown/hidden via
    -- OnEnter/OnLeave — we use ARTWORK not HIGHLIGHT so WoW doesn't
    -- auto-show it on every mouse-enabled row)
    row.highlight = row:CreateTexture(nil, "ARTWORK", nil, 7)
    row.highlight:SetColorTexture(0.85, 0.70, 0.20, 0.08)
    row.highlight:SetAllPoints()
    row.highlight:Hide()

    rowPool[index] = row
    return row
end

local function clearRowTooltip(row)
    row.challengeKey = nil
    row.challengeLevel = nil
    row.challengeActive = nil
    row.equipDetail = nil
    row.equipStatus = nil
    row.curatedKey = nil
    row.companionKey = nil
    row.selfFoundTip = nil
    row.highlight:Hide()
    row:SetScript("OnEnter", nil)
    row:SetScript("OnLeave", nil)
end

local function releaseExtraRows(used)
    for i = used + 1, #rowPool do
        clearRowTooltip(rowPool[i])
        rowPool[i]:Hide()
    end
end

----------------------------------------------------------------------
-- Tooltip for challenge rows
----------------------------------------------------------------------

local function onChallengeRowEnter(self)
    local key = self.challengeKey
    if not key then return end
    local desc = HCE.ChallengeDescriptions and HCE.ChallengeDescriptions[key]
    if not desc then return end

    self.highlight:Show()
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT", 8, 0)
    GameTooltip:ClearLines()

    -- Title line in gold
    GameTooltip:AddLine(key, 0.85, 0.70, 0.20)

    -- Status line
    if self.challengeActive then
        GameTooltip:AddLine("ACTIVE", 0.30, 0.90, 0.35)
    else
        GameTooltip:AddLine("Unlocks at level " .. tostring(self.challengeLevel or "?"), 0.55, 0.55, 0.55)
    end

    -- Separator
    GameTooltip:AddLine(" ")

    -- Full description, wrapped
    GameTooltip:AddLine(desc, 0.93, 0.93, 0.93, true)

    GameTooltip:Show()
end

local function onChallengeRowLeave(self)
    self.highlight:Hide()
    GameTooltip:Hide()
end

----------------------------------------------------------------------
-- Tooltip for equipment check rows
----------------------------------------------------------------------

local function onEquipRowEnter(self)
    local detail = self.equipDetail
    if not detail then return end

    self.highlight:Show()
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT", 8, 0)
    GameTooltip:ClearLines()

    local eqStatus = HCE.EquipmentCheck and HCE.EquipmentCheck.STATUS or {}
    if self.equipStatus == eqStatus.PASS then
        GameTooltip:AddLine("Requirement met", 0.30, 0.90, 0.35)
    elseif self.equipStatus == eqStatus.FAIL then
        GameTooltip:AddLine("Requirement not met", 1.00, 0.35, 0.30)
    else
        GameTooltip:AddLine("Cannot verify yet", 0.65, 0.65, 0.50)
    end

    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(detail, 0.93, 0.93, 0.93, true)

    -- Self-found settings hint
    if self.selfFoundTip then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("If you want to play without the self-found restriction or outside of Hardcore realms, you can turn off this requirement in the addon settings.", 0.55, 0.80, 0.95, true)
    end

    -- Show companion accepted creatures if this is a companion row
    if self.companionKey then
        local db = HCE.CompanionCheck and HCE.CompanionCheck.CompanionDB
        local entry = db and db[self.companionKey]
        if entry then
            GameTooltip:AddLine(" ")
            local names = {}
            if entry.creatureNames then
                for n in pairs(entry.creatureNames) do
                    table.insert(names, n)
                end
                table.sort(names)
            end
            if #names > 0 then
                GameTooltip:AddLine("Accepted companions (" .. #names .. "):", 0.90, 0.78, 0.25)
                for _, n in ipairs(names) do
                    GameTooltip:AddLine("  " .. n, 0.75, 0.75, 0.70)
                end
            end
            if entry.notes then
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(entry.notes, 0.55, 0.80, 0.95, true)
            end
        end
    end

    -- Show curated approved items if this row has a curated list
    local curatedKey = self.curatedKey
    if curatedKey then
        local items = HCE.CuratedItems and HCE.CuratedItems[curatedKey]
        if items then
            local count = 0
            for _ in pairs(items) do count = count + 1 end
            if count > 0 then
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine("Approved items (" .. count .. "):", 0.90, 0.78, 0.25)
                for itemID, note in pairs(items) do
                    local displayName
                    if type(note) == "string" then
                        displayName = note
                    else
                        displayName = "Item #" .. itemID
                    end
                    GameTooltip:AddLine("  " .. displayName, 0.75, 0.75, 0.70)
                end
            end
        end
    end

    GameTooltip:Show()
end

local function onEquipRowLeave(self)
    self.highlight:Hide()
    GameTooltip:Hide()
end

--- Tag a row as a challenge row so it shows a tooltip on hover.
--- Call this AFTER emitRow for the challenge.
local function tagChallengeRow(rowIndex, challengeKey, level, isActive)
    local row = rowPool[rowIndex]
    if not row then return end
    row.challengeKey    = challengeKey
    row.challengeLevel  = level
    row.challengeActive = isActive
    row:SetScript("OnEnter", onChallengeRowEnter)
    row:SetScript("OnLeave", onChallengeRowLeave)
end

----------------------------------------------------------------------
-- Row emitters
----------------------------------------------------------------------

-- returns a "tag" string and a tag color for a level-gated requirement
local function tagFor(level, playerLevel)
    if playerLevel >= level then
        return "ACTIVE", COLOR_ACTIVE
    else
        return "lv " .. level, COLOR_INACTIVE
    end
end

-- Emit a single-line row.  Returns the next row index and accumulated height used
local function emitRow(index, yOffset, tagText, tagColor, text, textColor, indent)
    local row = acquireRow(index)
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", contentFrame, "TOPLEFT", (indent or 0), -yOffset)
    row:SetPoint("RIGHT", contentFrame, "RIGHT", 0, 0)

    if tagText then
        row.tag:Show()
        row.tag:SetText(tagText)
        row.tag:SetTextColor(tagColor.r, tagColor.g, tagColor.b)
    else
        row.tag:Hide()
        row.tag:SetText("")
    end
    row.text:SetText(text or "")
    if textColor then
        row.text:SetTextColor(textColor.r, textColor.g, textColor.b)
    else
        row.text:SetTextColor(0.93, 0.93, 0.93)
    end

    row:Show()

    -- compute wrapped height so the next row lays out below the wrap
    local h = row.text:GetStringHeight()
    if h < ROW_HEIGHT then h = ROW_HEIGHT end
    row:SetHeight(h)

    return index + 1, yOffset + h + 2
end

local function emitSectionHeader(index, yOffset, title)
    yOffset = yOffset + SECTION_GAP
    local row = acquireRow(index)
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", contentFrame, "TOPLEFT", 0, -yOffset)
    row:SetPoint("RIGHT", contentFrame, "RIGHT", 0, 0)
    row:SetHeight(ROW_HEIGHT)

    row.tag:Hide()
    row.text:SetText(title)
    row.text:SetTextColor(COLOR_HEADER.r, COLOR_HEADER.g, COLOR_HEADER.b)
    row.text:ClearAllPoints()
    row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
    row.text:SetPoint("RIGHT", row, "RIGHT", 0, 0)
    row:Show()

    local nextIdx = index + 1
    -- separator line under the header
    if not row.separator then
        row.separator = row:CreateTexture(nil, "ARTWORK")
        row.separator:SetColorTexture(COLOR_HEADER.r, COLOR_HEADER.g, COLOR_HEADER.b, 0.35)
        row.separator:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 0, -2)
        row.separator:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, -2)
        row.separator:SetHeight(1)
    end
    row.separator:Show()
    return nextIdx, yOffset + ROW_HEIGHT + 4
end

----------------------------------------------------------------------
-- Rebuild contents
----------------------------------------------------------------------

function Panel.Refresh()
    if not frame or not frame:IsShown() then
        -- still update the header info so the next open is correct,
        -- but we don't need to rebuild rows while hidden
    end

    -- No frame yet? Nothing to do.
    if not frame then return end

    local key = HCE_CharDB and HCE_CharDB.selectedCharacter
    local char = key and HCE.GetCharacter and HCE.GetCharacter(key) or nil
    local playerLevel = UnitLevel("player") or 1
    local _, classToken = UnitClass("player")

    -- Reset row state that SectionHeader may have added, and clear
    -- tooltip data from previous layout (rows are pooled and reused)
    for _, row in ipairs(rowPool) do
        if row.separator then row.separator:Hide() end
        row.text:ClearAllPoints()
        row.text:SetPoint("TOPLEFT", row.tag, "TOPRIGHT", 4, 0)
        row.text:SetPoint("RIGHT", row, "RIGHT", -2, 0)
        clearRowTooltip(row)
    end

    -- Header
    if char then
        local col = classColor(char.class)
        headerLabel:SetText("|cff" .. col .. char.name .. "|r")
        subLabel:SetText(char.spec .. " " .. titleCase(char.class) .. " · lv " .. playerLevel .. " / 60")
    else
        headerLabel:SetText("|cffffd100No enhanced class selected|r")
        subLabel:SetText("Type |cffffd100/hce pick|r to choose one")
    end

    -- Show/hide lore button (only for core-set characters)
    if Panel._loreButton then
        local isAdditional = char and HCE.AdditionalCharacters and HCE.AdditionalCharacters[char.name]
        if char and not isAdditional then
            Panel._loreButton:Show()
        else
            Panel._loreButton:Hide()
        end
    end

    local index  = 1
    local yOff   = 0

    if not char then
        countLabel:SetText("")
        local row = acquireRow(index)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", contentFrame, "TOPLEFT", 0, -6)
        row:SetPoint("RIGHT", contentFrame, "RIGHT", 0, 0)
        row:SetHeight(ROW_HEIGHT * 3)
        row.tag:Hide()
        row.text:SetText("Open the selection window with |cffffd100/hce ui|r to pick an enhanced class for this character.")
        row.text:SetTextColor(COLOR_SUBTXT.r, COLOR_SUBTXT.g, COLOR_SUBTXT.b)
        row:Show()
        releaseExtraRows(1)
        contentFrame:SetHeight(ROW_HEIGHT * 3 + 12)
        return
    end

    -- Count active requirements using ProgressSummary as the source of truth
    local summary = HCE.Progress and HCE.Progress.Collect and HCE.Progress.Collect()
    local activeCount, totalCount = 0, 0
    if summary and summary.counts then
        local c = summary.counts
        activeCount = c.pass + c.fail + c.unchecked
        totalCount  = c.total
    end

    countLabel:SetText(activeCount .. " / " .. totalCount .. " requirements active")

    -- Progress bar (built once, updated each refresh)
    if HCE.Progress and HCE.Progress.BuildBar then
        -- The bar anchors below countLabel's parent (the summary frame).
        -- We build it lazily on first refresh, then just update.
        if not Panel._progressBar then
            -- Find the summary frame (countLabel's parent)
            local summaryFrame = countLabel:GetParent()
            Panel._progressBar = HCE.Progress.BuildBar(frame, summaryFrame, -2)
        end
        -- Defer the bar update slightly so all check modules have
        -- had time to write their results this frame
        C_Timer.After(0.05, function()
            if HCE.Progress.UpdateBar then HCE.Progress.UpdateBar() end
        end)
    end

    -- Race / gender / self-found summary row
    -- If self-found is required, append a tracking indicator
    local sfResults = HCE.SelfFoundCheck and HCE.SelfFoundCheck.GetResults() or {}
    local sfStatus  = HCE.SelfFoundCheck and HCE.SelfFoundCheck.STATUS or {}
    local sfEnabled = not HCE.SelfFoundEnabled or HCE.SelfFoundEnabled()
    local sf = ""
    if char.selfFound then
        if not sfEnabled then
            sf = " · |cff888888self-found (disabled)|r"
        else
            local sfBuff = sfResults.selfFound
            if sfBuff then
                if sfBuff.status == sfStatus.PASS then
                    sf = " · |cff4de64dself-found |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t|r"
                elseif sfBuff.status == sfStatus.FAIL then
                    sf = " · |cffff5a4cself-found |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t|r"
                else
                    sf = " · |cffa5a582self-found ?|r"
                end
            else
                sf = " · |cffaaddffself-found|r"
            end
        end
    end
    index, yOff = emitRow(index, yOff, nil, nil,
        char.race .. " · " .. char.gender .. sf, COLOR_SUBTXT)
    -- Tag self-found row for tooltip on hover
    if char.selfFound then
        local row = rowPool[index - 1]
        if row then
            row.selfFoundTip = true
            if sfEnabled then
                local sfBuff = sfResults.selfFound
                if sfBuff and sfBuff.detail then
                    row.equipDetail = sfBuff.detail
                    row.equipStatus = sfBuff.status
                end
            else
                row.equipDetail = "Self-found tracking is disabled in addon settings."
                row.equipStatus = "unchecked"
            end
            row:SetScript("OnEnter", onEquipRowEnter)
            row:SetScript("OnLeave", onEquipRowLeave)
        end
    end

    -- Professions section (with tracking indicators from ProfessionCheck)
    local profResults = HCE.ProfessionCheck and HCE.ProfessionCheck.GetResults() or {}
    local profStatus  = HCE.ProfessionCheck and HCE.ProfessionCheck.STATUS or {}
    if char.professions and #char.professions > 0 then
        index, yOff = emitSectionHeader(index, yOff, "PROFESSIONS")
        for _, profName in ipairs(char.professions) do
            local res = profResults[profName]
            local tag, col, txtCol
            if playerLevel < 5 then
                tag = "lv 5"
                col = COLOR_INACTIVE
                txtCol = COLOR_INACTIVE
            else
                tag = "ACTIVE"
                col = COLOR_ACTIVE
                txtCol = nil
            end
            -- Append a tracking indicator
            local suffix = ""
            if res and playerLevel >= 5 then
                if res.status == profStatus.PASS then
                    suffix = "  |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t"   -- green checkmark
                elseif res.status == profStatus.FAIL then
                    suffix = "  |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t"   -- red X
                elseif res.status == "unchecked" then
                    suffix = "  |cffa5a582?|r"              -- muted ?
                end
            end
            index, yOff = emitRow(index, yOff, tag, col, profName .. suffix, txtCol)
            -- Tag profession rows for tooltip on hover (show rank detail)
            if res and playerLevel >= 5 and res.detail then
                local row = rowPool[index - 1]
                if row then
                    row.equipDetail = res.detail
                    row.equipStatus = res.status
                    row:SetScript("OnEnter", onEquipRowEnter)
                    row:SetScript("OnLeave", onEquipRowLeave)
                end
            end
        end
    end

    -- Challenges section (with tracking from ChallengeCheck + SelfFoundCheck)
    local chResults = HCE.ChallengeCheck and HCE.ChallengeCheck.GetResults() or {}
    local chStatus  = HCE.ChallengeCheck and HCE.ChallengeCheck.STATUS or {}
    if char.challenges and #char.challenges > 0 then
        -- Determine which challenges are excluded by easy mode
        local easyExclude = {}
        if HCE.EasyModeEnabled and HCE.EasyModeEnabled() then
            easyExclude = (HCE.EasyModeExclusions and HCE.EasyModeExclusions[char.name]) or {}
        end
        -- Check if we have any non-excluded challenges to show
        local hasVisible = false
        for _, ch in ipairs(char.challenges) do
            if not easyExclude[ch.desc] then hasVisible = true; break end
        end
        if hasVisible then
            index, yOff = emitSectionHeader(index, yOff, "CHALLENGES")
        end
        for i, ch in ipairs(char.challenges) do
            -- Skip challenges excluded by easy mode
            if easyExclude[ch.desc] then
                -- do nothing, challenge is hidden
            else
            local superseded = ch.endLevel and playerLevel > ch.endLevel
            local isActive = (playerLevel >= ch.level) and not superseded
            local tag, col, txtCol
            if ch.endLevel then
                tag = "lv " .. ch.level .. "-" .. ch.endLevel
                if superseded then
                    col = COLOR_INACTIVE
                    txtCol = COLOR_INACTIVE
                elseif isActive then
                    col = COLOR_ACTIVE
                    txtCol = COLOR_INACTIVE
                else
                    col = COLOR_INACTIVE
                    txtCol = COLOR_INACTIVE
                end
            else
                tag, col = tagFor(ch.level, playerLevel)
                txtCol = isActive and nil or COLOR_INACTIVE
            end

            -- Build a tracking indicator from ChallengeCheck results.
            local suffix = ""
            local checkResult = chResults[i]
            if isActive and checkResult then
                if checkResult.status == chStatus.PASS then
                    suffix = "  |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t"
                elseif checkResult.status == chStatus.FAIL then
                    suffix = "  |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t"
                elseif checkResult.status == chStatus.UNCHECKED then
                    suffix = "  |cffa5a582?|r"
                end
            end

            index, yOff = emitRow(index, yOff, tag, col, ch.desc .. suffix, txtCol)
            -- Tag this row for hover tooltip (index-1 because emitRow already incremented)
            tagChallengeRow(index - 1, ch.desc, ch.level, isActive)

            -- Check if this challenge is excludable by easy mode (for tooltip hint)
            local isExcludable = (HCE.EasyModeExclusions and HCE.EasyModeExclusions[char.name]
                                  and HCE.EasyModeExclusions[char.name][ch.desc]) or false

            -- Add a hover tooltip with the check detail from ChallengeCheck
            local row = rowPool[index - 1]
            if row then
                if isActive and checkResult and checkResult.detail then
                    row.equipDetail = checkResult.detail
                    row.equipStatus = checkResult.status
                end
                -- Keep the challenge description tooltip on enter
                -- and also append the check detail + easy mode hint below it
                local origEnter = row:GetScript("OnEnter")
                local capturedResult = (isActive and checkResult) or nil
                local capturedExcludable = isExcludable
                row:SetScript("OnEnter", function(self)
                    if origEnter then origEnter(self) end
                    if GameTooltip:IsShown() then
                        if capturedResult and capturedResult.detail then
                            GameTooltip:AddLine(" ")
                            local statusLabel
                            if capturedResult.status == chStatus.PASS then
                                statusLabel = "|cff4de64dPassing|r"
                            elseif capturedResult.status == chStatus.FAIL then
                                statusLabel = "|cffff5a4cViolation detected|r"
                            else
                                statusLabel = "|cffa5a582Cannot fully verify yet|r"
                            end
                            GameTooltip:AddLine("Status: " .. statusLabel, 0.93, 0.93, 0.93)
                            GameTooltip:AddLine(capturedResult.detail, 0.75, 0.75, 0.75, true)
                        end
                        if capturedExcludable then
                            GameTooltip:AddLine(" ")
                            GameTooltip:AddLine("This challenge can be disabled by turning on Easy Mode in the addon settings.", 0.55, 0.80, 0.95, true)
                        end
                        GameTooltip:Show()
                    end
                end)
            end

            local extra = HCE.ChallengeDescriptions and HCE.ChallengeDescriptions[ch.desc]
            if extra then
                index, yOff = emitRow(index, yOff, nil, nil, "  " .. extra, COLOR_SUBTXT)
                yOff = yOff + 4  -- extra spacing after description text
            end
            end  -- end of else (not excluded)
        end
    end

    -- Talents section (spec tracking + per-talent requirements)
    -- Run a fresh check so results are always current (the API calls
    -- are cheap and this avoids stale-cache / timing-race issues).
    if HCE.TalentCheck and HCE.TalentCheck.RunCheck then
        local tok, terr = pcall(HCE.TalentCheck.RunCheck)
        if not tok and HCE.Print then
            HCE.Print("|cffff5555Talent check error:|r " .. tostring(terr))
        end
    end
    local talentResult = HCE.TalentCheck and HCE.TalentCheck.GetResults() or {}
    local talentStatus = HCE.TalentCheck and HCE.TalentCheck.STATUS or {}
    if char.spec then
        index, yOff = emitSectionHeader(index, yOff, "TALENTS")

        -- Row 1: spec label (informational only, not tracked)
        index, yOff = emitRow(index, yOff, nil, nil,
            "Spec: " .. char.spec, COLOR_SUBTXT)

        -- Per-talent requirement rows (indented under the spec row)
        -- Read directly from TalentRequirements data so rows are ALWAYS
        -- visible, even before the talent scan has run.  Check results
        -- (from talentResult.talentReqs) are overlaid for ✓/✗/? status.
        local rawReqs   = HCE.TalentRequirements and HCE.TalentRequirements[char.name]
        local checkReqs = talentResult.talentReqs
        if rawReqs then
            for ri, req in ipairs(rawReqs) do
                local superseded = req.endLevel and playerLevel > req.endLevel
                local isActive = (playerLevel >= req.level) and not superseded
                local tTag, tCol, tTxtCol
                if req.endLevel then
                    tTag = "lv " .. req.level .. "-" .. req.endLevel
                    if superseded then
                        tCol = COLOR_INACTIVE
                        tTxtCol = COLOR_INACTIVE
                    elseif isActive then
                        tCol = COLOR_ACTIVE
                        tTxtCol = nil
                    else
                        tCol = COLOR_INACTIVE
                        tTxtCol = COLOR_INACTIVE
                    end
                elseif superseded then
                    tTag = "lv " .. req.level
                    tCol = COLOR_INACTIVE
                    tTxtCol = COLOR_INACTIVE
                elseif isActive then
                    tTag = "ACTIVE"
                    tCol = COLOR_ACTIVE
                    tTxtCol = nil
                else
                    tTag = "lv " .. req.level
                    tCol = COLOR_INACTIVE
                    tTxtCol = COLOR_INACTIVE
                end
                -- Use check result for this index if available
                local chk = checkReqs and checkReqs[ri]
                local maxRank = (chk and chk.maxRank) or req.rank
                local rankStr = req.rank .. "/" .. maxRank
                local tText = req.name .. " (" .. rankStr .. ")"
                local tSuffix = ""
                if isActive then
                    if chk and chk.status == talentStatus.PASS then
                        tSuffix = "  |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t"
                    elseif chk and chk.status == talentStatus.FAIL then
                        tSuffix = "  |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t"
                    else
                        tSuffix = "  |cffa5a582?|r"
                    end
                end
                index, yOff = emitRow(index, yOff, tTag, tCol, tText .. tSuffix, tTxtCol)
                -- Hover tooltip
                if isActive then
                    local tRow = rowPool[index - 1]
                    if tRow then
                        tRow.equipDetail = (chk and chk.detail) or "Talent check pending\226\128\166"
                        tRow.equipStatus = (chk and chk.status) or "unchecked"
                        tRow:SetScript("OnEnter", onEquipRowEnter)
                        tRow:SetScript("OnLeave", onEquipRowLeave)
                    end
                end
            end
        end
    end

    -- Equipment section
    local eqResults = HCE.EquipmentCheck and HCE.EquipmentCheck.GetResults() or {}
    local eqStatus  = HCE.EquipmentCheck and HCE.EquipmentCheck.STATUS or {}
    if char.equipment and #char.equipment > 0 then
        index, yOff = emitSectionHeader(index, yOff, "EQUIPMENT")
        for i, eq in ipairs(char.equipment) do
            local superseded = eq.endLevel and playerLevel > eq.endLevel
            local isActive = playerLevel >= eq.level and not superseded
            local tag, col
            if eq.endLevel then
                tag = "lv " .. eq.level .. "-" .. eq.endLevel
                if superseded then
                    col = COLOR_INACTIVE
                elseif isActive then
                    col = COLOR_ACTIVE
                else
                    col = COLOR_INACTIVE
                end
            else
                tag, col = tagFor(eq.level, playerLevel)
            end
            local txtCol = isActive and nil or COLOR_INACTIVE
            -- Append a tracking indicator for active requirements
            local suffix = ""
            local res = eqResults[i]
            if res and isActive then
                if res.status == eqStatus.PASS then
                    suffix = "  |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t"   -- green checkmark
                elseif res.status == eqStatus.FAIL then
                    suffix = "  |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t"   -- red X
                elseif res.status == eqStatus.UNCHECKED then
                    suffix = "  |cffa5a582?|r"              -- muted ?
                end
            end
            index, yOff = emitRow(index, yOff, tag, col, eq.desc .. suffix, txtCol)
            -- Tag equipment rows for tooltip on hover (show check detail + curated items)
            local row = rowPool[index - 1]
            if row then
                -- Attach curated list key so tooltip can show approved items
                local keyMap = HCE.CuratedKeyForDesc or {}
                row.curatedKey = keyMap[eq.desc]

                if res and isActive and res.detail then
                    row.equipDetail = res.detail
                    row.equipStatus = res.status
                    row:SetScript("OnEnter", onEquipRowEnter)
                    row:SetScript("OnLeave", onEquipRowLeave)
                elseif row.curatedKey then
                    -- Even without a check result, show curated items on hover
                    row.equipDetail = "Hover to see approved items"
                    row.equipStatus = "unchecked"
                    row:SetScript("OnEnter", onEquipRowEnter)
                    row:SetScript("OnLeave", onEquipRowLeave)
                end
            end
        end
    end

    -- Quests section
    local qcResults = HCE.QuestCheck and HCE.QuestCheck.GetResults() or {}
    local qcStatus  = HCE.QuestCheck and HCE.QuestCheck.STATUS or {}
    if char.quests and #char.quests > 0 then
        index, yOff = emitSectionHeader(index, yOff, "QUESTS")

        -- Build group boundaries: either from questGroups or a single group
        local groups
        if char.questGroups then
            groups = char.questGroups
        elseif char.questTheme then
            groups = { { theme = char.questTheme, count = #char.quests } }
        else
            groups = { { theme = nil, count = #char.quests } }
        end

        local questIdx = 1
        for _, group in ipairs(groups) do
            -- Sub-header for each quest group theme
            if group.theme then
                index, yOff = emitRow(index, yOff, nil, nil,
                    group.theme, COLOR_SUBTXT)
            end

            for _ = 1, group.count do
                local quest = char.quests[questIdx]
                if not quest then break end
                local i = questIdx
                questIdx = questIdx + 1

                local isActive = (playerLevel >= quest.level)
                local tag, col = tagFor(quest.level, playerLevel)
                local txtCol = isActive and nil or COLOR_INACTIVE

                local suffix = ""
                local res = qcResults[i]
                if res and isActive then
                    if res.status == qcStatus.PASS then
                        suffix = "  |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t"
                    elseif res.status == qcStatus.FAIL then
                        suffix = "  |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t"
                    elseif res.status == qcStatus.UNCHECKED then
                        suffix = "  |cffa5a582?|r"
                    end
                end

                index, yOff = emitRow(index, yOff, tag, col, quest.name .. suffix, txtCol)

                -- Tooltip on hover showing quest completion detail
                if res and isActive and res.detail then
                    local row = rowPool[index - 1]
                    if row then
                        row.equipDetail = res.detail
                        row.equipStatus = res.status
                        row:SetScript("OnEnter", onEquipRowEnter)
                        row:SetScript("OnLeave", onEquipRowLeave)
                    end
                end
            end
        end
    end

    -- Companion / pet / mount
    local hasAnimals = char.companion or char.pet or char.mount
    if hasAnimals then
        index, yOff = emitSectionHeader(index, yOff, "MOUNTS/COMPANIONS/PETS")
        if char.companion then
            local tag, col = tagFor(char.companion.level, playerLevel)
            local txtCol = (playerLevel >= char.companion.level) and nil or COLOR_INACTIVE
            -- Append tracking indicator from CompanionCheck
            local suffix = ""
            local compResult = HCE_CharDB and HCE_CharDB.companionResults
            local isCompActive = playerLevel >= char.companion.level
            if isCompActive and compResult then
                if compResult.status == "pass" then
                    suffix = "  |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t"   -- green ✓
                elseif compResult.status == "fail" then
                    suffix = "  |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t"   -- red X
                elseif compResult.status == "unchecked" then
                    suffix = "  |cffa5a582?|r"              -- muted ?
                end
            end
            index, yOff = emitRow(index, yOff, tag, col, "Companion: " .. char.companion.desc .. suffix, txtCol)
            -- Tooltip: always attach so hover shows CompanionDB info
            local compRow = rowPool[index - 1]
            if compRow then
                compRow.companionKey = char.companion.desc
                if isCompActive and compResult then
                    compRow.equipDetail = compResult.detail or "Checking..."
                    compRow.equipStatus = compResult.status
                else
                    compRow.equipDetail = "Activates at level " .. char.companion.level
                    compRow.equipStatus = "unchecked"
                end
                compRow:SetScript("OnEnter", onEquipRowEnter)
                compRow:SetScript("OnLeave", onEquipRowLeave)
            end
        end
        if char.pet then
            local tag, col = tagFor(char.pet.level, playerLevel)
            local txtCol = (playerLevel >= char.pet.level) and nil or COLOR_INACTIVE
            -- Append tracking indicator from HunterPetCheck
            local hpSuffix = ""
            local hpResult = HCE_CharDB and HCE_CharDB.hunterPetResults
            local isPetActive = playerLevel >= char.pet.level
            if isPetActive and hpResult then
                if hpResult.status == "pass" then
                    hpSuffix = "  |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t"   -- green ✓
                elseif hpResult.status == "fail" then
                    hpSuffix = "  |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t"   -- red X
                elseif hpResult.status == "unchecked" then
                    hpSuffix = "  |cffa5a582?|r"              -- muted ?
                end
            end
            index, yOff = emitRow(index, yOff, tag, col, "Hunter pet: " .. char.pet.desc .. hpSuffix, txtCol)
            -- Tooltip on hover showing hunter pet check detail
            if isPetActive and hpResult and hpResult.detail then
                local row = rowPool[index - 1]
                if row then
                    row.equipDetail = hpResult.detail
                    row.equipStatus = hpResult.status
                    row:SetScript("OnEnter", onEquipRowEnter)
                    row:SetScript("OnLeave", onEquipRowLeave)
                end
            end
        end
        if char.mount then
            local tag, col = tagFor(char.mount.level, playerLevel)
            local txtCol = (playerLevel >= char.mount.level) and nil or COLOR_INACTIVE
            -- Append tracking indicator from MountCheck
            local mtSuffix = ""
            local mtResult = HCE_CharDB and HCE_CharDB.mountResults
            local isMtActive = playerLevel >= char.mount.level
            if isMtActive and mtResult then
                if mtResult.status == "pass" then
                    mtSuffix = "  |TInterface\\RaidFrame\\ReadyCheck-Ready:0|t"   -- green ✓
                elseif mtResult.status == "fail" then
                    mtSuffix = "  |TInterface\\RaidFrame\\ReadyCheck-NotReady:0|t"   -- red X
                elseif mtResult.status == "unchecked" then
                    mtSuffix = "  |cffa5a582?|r"              -- muted ?
                end
            end
            index, yOff = emitRow(index, yOff, tag, col, "Mount: " .. char.mount.desc .. mtSuffix, txtCol)
            -- Tooltip on hover showing mount check detail
            if isMtActive and mtResult and mtResult.detail then
                local row = rowPool[index - 1]
                if row then
                    row.equipDetail = mtResult.detail
                    row.equipStatus = mtResult.status
                    row:SetScript("OnEnter", onEquipRowEnter)
                    row:SetScript("OnLeave", onEquipRowLeave)
                end
            end
        end
    end

    -- Recommended profession (not a requirement — shown like gameplay tips)
    if char.recommendedProfession then
        local COLOR_TIPS = { r = 0.55, g = 0.70, b = 0.85 }
        local rp = char.recommendedProfession
        index, yOff = emitSectionHeader(index, yOff, "RECOMMENDED")
        local rowIdx = index
        index, yOff = emitRow(index, yOff, nil, nil,
            "Profession: " .. rp.name, COLOR_TIPS)
        local row = rowPool[rowIdx]
        if row then
            row.tipTitle = "Recommended: " .. rp.name
            row.tipDesc  = rp.reason
            row:SetScript("OnEnter", function(self)
                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                GameTooltip:ClearLines()
                GameTooltip:AddLine(self.tipTitle, 0.55, 0.70, 0.85)
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(self.tipDesc, 0.93, 0.93, 0.93, true)
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine("This is a suggestion, not a requirement.", 0.55, 0.55, 0.50, true)
                GameTooltip:Show()
            end)
            row:SetScript("OnLeave", function()
                GameTooltip:Hide()
            end)
        end
    end

    -- Gameplay tips (expanded via GameplayTips module)
    if char.gameplay and char.gameplay ~= "" then
        index, yOff = emitSectionHeader(index, yOff, "GAMEPLAY")
        local COLOR_TIPS = { r = 0.55, g = 0.70, b = 0.85 }
        local tips = HCE.GameplayTips and HCE.GameplayTips.Parse and HCE.GameplayTips.Parse(char.gameplay)
        if tips and #tips > 0 then
            for _, tip in ipairs(tips) do
                local rowIdx = index
                index, yOff = emitRow(index, yOff, nil, nil,
                    tip.title, COLOR_TIPS)
                -- Add hover tooltip with the full description
                local row = rowPool[rowIdx]
                if row then
                    row.tipDesc = tip.desc
                    row.tipTitle = tip.title
                    row:SetScript("OnEnter", function(self)
                        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                        GameTooltip:ClearLines()
                        GameTooltip:AddLine(self.tipTitle, 0.55, 0.70, 0.85)
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine(self.tipDesc, 0.93, 0.93, 0.93, true)
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine("This is a flavour suggestion, not a requirement.", 0.55, 0.55, 0.50, true)
                        GameTooltip:Show()
                    end)
                    row:SetScript("OnLeave", function()
                        GameTooltip:Hide()
                    end)
                end
            end
        else
            -- Fallback: show raw text if GameplayTips module not loaded
            index, yOff = emitRow(index, yOff, nil, nil, char.gameplay, COLOR_SUBTXT)
        end
    end

    releaseExtraRows(index - 1)
    contentFrame:SetHeight(math.max(yOff + 10, 1))
end

----------------------------------------------------------------------
-- Build the frame
----------------------------------------------------------------------

local function BuildFrame()
    if frame then return frame end

    frame = CreateFrame("Frame", "HCE_RequirementsPanel", UIParent, "BackdropTemplate")
    frame:SetSize(FRAME_WIDTH, FRAME_HEIGHT)
    frame:SetFrameStrata("MEDIUM")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)

    -- Close panel with Escape key
    tinsert(UISpecialFrames, "HCE_RequirementsPanel")

    -- Backdrop — darker and more angular than BasicFrameTemplate so the
    -- panel reads as a sidebar, not a popup dialog.
    if frame.SetBackdrop then
        frame:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
            insets   = { left = 1, right = 1, top = 1, bottom = 1 },
        })
        frame:SetBackdropColor(0.05, 0.06, 0.08, 0.92)
        frame:SetBackdropBorderColor(0.85, 0.70, 0.20, 0.85)
    end

    -- Title bar -------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, frame)
    titleBar:SetPoint("TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", 0, 0)
    titleBar:SetHeight(40)
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function()
        if not db().locked then frame:StartMoving() end
    end)
    titleBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
        local p, _, rp, x, y = frame:GetPoint()
        local s = db()
        s.point, s.relPoint, s.x, s.y = p, rp, x, y
    end)

    local titleBg = titleBar:CreateTexture(nil, "BACKGROUND")
    titleBg:SetColorTexture(0.85, 0.70, 0.20, 0.12)
    titleBg:SetAllPoints(titleBar)

    local titleStripe = titleBar:CreateTexture(nil, "ARTWORK")
    titleStripe:SetColorTexture(0.85, 0.70, 0.20, 0.85)
    titleStripe:SetPoint("BOTTOMLEFT", titleBar, "BOTTOMLEFT", 0, 0)
    titleStripe:SetPoint("BOTTOMRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
    titleStripe:SetHeight(1)

    headerLabel = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    headerLabel:SetPoint("TOPLEFT", titleBar, "TOPLEFT", PAD_X, -PAD_Y)
    headerLabel:SetPoint("RIGHT", titleBar, "RIGHT", -58, 0)
    headerLabel:SetJustifyH("LEFT")
    headerLabel:SetText("Hardcore Classes Enhanced")

    subLabel = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    subLabel:SetPoint("TOPLEFT", headerLabel, "BOTTOMLEFT", 0, -2)
    subLabel:SetJustifyH("LEFT")
    subLabel:SetTextColor(COLOR_SUBTXT.r, COLOR_SUBTXT.g, COLOR_SUBTXT.b)
    subLabel:SetText("")

    -- Close button
    closeButton = CreateFrame("Button", nil, titleBar, "UIPanelCloseButton")
    closeButton:SetSize(24, 24)
    closeButton:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -4, -4)
    closeButton:SetScript("OnClick", function() Panel.Hide() end)

    -- Settings button (gear icon)
    local settingsButton = CreateFrame("Button", nil, titleBar)
    settingsButton:SetSize(20, 20)
    settingsButton:SetPoint("RIGHT", closeButton, "LEFT", -2, 0)
    settingsButton.icon = settingsButton:CreateTexture(nil, "ARTWORK")
    settingsButton.icon:SetAllPoints()
    settingsButton.icon:SetTexture("Interface\\Buttons\\UI-OptionsButton")
    settingsButton:SetScript("OnClick", function()
        if HCE.SettingsPanel and HCE.SettingsPanel.Toggle then
            HCE.SettingsPanel.Toggle()
        end
    end)
    settingsButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Settings")
        GameTooltip:Show()
    end)
    settingsButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Pin/lock button
    pinButton = CreateFrame("Button", nil, titleBar)
    pinButton:SetSize(20, 20)
    pinButton:SetPoint("RIGHT", settingsButton, "LEFT", -2, 0)
    pinButton.icon = pinButton:CreateTexture(nil, "ARTWORK")
    pinButton.icon:SetAllPoints()
    pinButton.icon:SetTexture("Interface\\Buttons\\LockButton-Unlocked-Up")
    pinButton:SetScript("OnClick", function()
        local s = db()
        s.locked = not s.locked
        Panel.UpdatePinIcon()
    end)
    -- Catalog button (book icon)
    local catalogButton = CreateFrame("Button", nil, titleBar)
    catalogButton:SetSize(20, 20)
    catalogButton:SetPoint("RIGHT", pinButton, "LEFT", -2, 0)
    catalogButton.icon = catalogButton:CreateTexture(nil, "ARTWORK")
    catalogButton.icon:SetAllPoints()
    catalogButton.icon:SetTexture("Interface\\MINIMAP\\TRACKING\\Class")
    catalogButton:SetScript("OnClick", function()
        if HCE.CatalogUI and HCE.CatalogUI.Toggle then
            HCE.CatalogUI.Toggle()
        end
    end)
    catalogButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Browse all enhanced classes")
        GameTooltip:Show()
    end)
    catalogButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Lore button (scroll icon) — only shown for core-set characters
    local loreButton = CreateFrame("Button", nil, titleBar)
    loreButton:SetSize(15, 15)
    loreButton:SetPoint("RIGHT", catalogButton, "LEFT", -2, 0)
    loreButton.icon = loreButton:CreateTexture(nil, "ARTWORK")
    loreButton.icon:SetAllPoints()
    loreButton.icon:SetTexture("Interface\\ICONS\\INV_Scroll_02")
    loreButton.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    loreButton:SetScript("OnClick", function()
        Panel.ToggleLore()
    end)
    loreButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("Read lore background")
        GameTooltip:Show()
    end)
    loreButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
    loreButton:Hide()  -- shown/hidden by Refresh based on character
    Panel._loreButton = loreButton

    pinButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText(db().locked and "Unlock panel" or "Lock panel position")
        GameTooltip:Show()
    end)
    pinButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

    function Panel.UpdatePinIcon()
        if db().locked then
            pinButton.icon:SetTexture("Interface\\Buttons\\LockButton-Locked-Up")
        else
            pinButton.icon:SetTexture("Interface\\Buttons\\LockButton-Unlocked-Up")
        end
    end

    -- Summary bar -----------------------------------------------------
    local summary = CreateFrame("Frame", nil, frame)
    summary:SetPoint("TOPLEFT", titleBar, "BOTTOMLEFT", 0, 0)
    summary:SetPoint("TOPRIGHT", titleBar, "BOTTOMRIGHT", 0, 0)
    summary:SetHeight(22)

    countLabel = summary:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    countLabel:SetPoint("LEFT", summary, "LEFT", PAD_X, 0)
    countLabel:SetTextColor(0.85, 0.70, 0.20)

    local summaryLine = summary:CreateTexture(nil, "ARTWORK")
    summaryLine:SetColorTexture(0.85, 0.70, 0.20, 0.25)
    summaryLine:SetPoint("BOTTOMLEFT", summary, "BOTTOMLEFT", PAD_X, 0)
    summaryLine:SetPoint("BOTTOMRIGHT", summary, "BOTTOMRIGHT", -PAD_X, 0)
    summaryLine:SetHeight(1)

    -- Progress bar spacer — reserve vertical space so the scroll frame
    -- starts below the progress bar when it's present.  The bar itself
    -- is created lazily in Panel.Refresh; this just offsets the scroll.
    local PROGRESS_H = 42
    local progressSpacer = CreateFrame("Frame", nil, frame)
    progressSpacer:SetPoint("TOPLEFT", summary, "BOTTOMLEFT", 0, 0)
    progressSpacer:SetPoint("TOPRIGHT", summary, "BOTTOMRIGHT", 0, 0)
    progressSpacer:SetHeight(PROGRESS_H)

    -- Scroll frame ----------------------------------------------------
    scrollFrame = CreateFrame("ScrollFrame", "HCE_RequirementsPanelScroll", frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", progressSpacer, "BOTTOMLEFT", PAD_X, -4)
    scrollFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -30, PAD_Y)

    contentFrame = CreateFrame("Frame", nil, scrollFrame)
    contentFrame:SetSize(FRAME_WIDTH - PAD_X - 34, 10)
    scrollFrame:SetScrollChild(contentFrame)

    -- Restore position
    local s = db()
    frame:ClearAllPoints()
    frame:SetPoint(s.point or "CENTER", UIParent, s.relPoint or "CENTER", s.x or 0, s.y or 0)
    Panel.UpdatePinIcon()

    frame:Hide()
    return frame
end

----------------------------------------------------------------------
-- Lore popup
----------------------------------------------------------------------

local loreFrame  -- created once, toggled

local function BuildLoreFrame()
    if loreFrame then return loreFrame end

    loreFrame = CreateFrame("Frame", "HCE_LoreFrame", UIParent, "BackdropTemplate")
    loreFrame:SetSize(340, 320)
    loreFrame:SetFrameStrata("DIALOG")
    loreFrame:SetClampedToScreen(true)
    loreFrame:SetMovable(true)
    loreFrame:EnableMouse(true)
    tinsert(UISpecialFrames, "HCE_LoreFrame")

    if loreFrame.SetBackdrop then
        loreFrame:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
            insets   = { left = 1, right = 1, top = 1, bottom = 1 },
        })
        loreFrame:SetBackdropColor(0.06, 0.05, 0.03, 0.95)
        loreFrame:SetBackdropBorderColor(0.70, 0.55, 0.15, 0.85)
    end

    -- Title bar
    local loreTitleBar = CreateFrame("Frame", nil, loreFrame)
    loreTitleBar:SetPoint("TOPLEFT", 0, 0)
    loreTitleBar:SetPoint("TOPRIGHT", 0, 0)
    loreTitleBar:SetHeight(32)
    loreTitleBar:EnableMouse(true)
    loreTitleBar:RegisterForDrag("LeftButton")
    loreTitleBar:SetScript("OnDragStart", function() loreFrame:StartMoving() end)
    loreTitleBar:SetScript("OnDragStop", function() loreFrame:StopMovingOrSizing() end)

    local loreTitleBg = loreTitleBar:CreateTexture(nil, "BACKGROUND")
    loreTitleBg:SetColorTexture(0.70, 0.55, 0.15, 0.15)
    loreTitleBg:SetAllPoints(loreTitleBar)

    local loreTitleStripe = loreTitleBar:CreateTexture(nil, "ARTWORK")
    loreTitleStripe:SetColorTexture(0.70, 0.55, 0.15, 0.65)
    loreTitleStripe:SetPoint("BOTTOMLEFT", loreTitleBar, "BOTTOMLEFT", 0, 0)
    loreTitleStripe:SetPoint("BOTTOMRIGHT", loreTitleBar, "BOTTOMRIGHT", 0, 0)
    loreTitleStripe:SetHeight(1)

    loreFrame.titleText = loreTitleBar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    loreFrame.titleText:SetPoint("LEFT", loreTitleBar, "LEFT", 12, 0)
    loreFrame.titleText:SetPoint("RIGHT", loreTitleBar, "RIGHT", -28, 0)
    loreFrame.titleText:SetJustifyH("LEFT")
    loreFrame.titleText:SetTextColor(0.85, 0.70, 0.20)

    local loreClose = CreateFrame("Button", nil, loreTitleBar, "UIPanelCloseButton")
    loreClose:SetSize(22, 22)
    loreClose:SetPoint("TOPRIGHT", loreTitleBar, "TOPRIGHT", -2, -2)
    loreClose:SetScript("OnClick", function() loreFrame:Hide() end)

    -- Scroll frame for lore body
    local loreScroll = CreateFrame("ScrollFrame", "HCE_LoreScroll", loreFrame, "UIPanelScrollFrameTemplate")
    loreScroll:SetPoint("TOPLEFT", loreTitleBar, "BOTTOMLEFT", 12, -8)
    loreScroll:SetPoint("BOTTOMRIGHT", loreFrame, "BOTTOMRIGHT", -30, 12)

    -- 340 frame - 12 left pad - 30 scrollbar - 12 right margin = ~280
    local LORE_TEXT_W = 276

    local loreContent = CreateFrame("Frame", nil, loreScroll)
    loreContent:SetWidth(LORE_TEXT_W + 4)
    loreContent:SetHeight(1)
    loreScroll:SetScrollChild(loreContent)

    loreFrame.body = loreContent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    loreFrame.body:SetPoint("TOPLEFT", loreContent, "TOPLEFT", 0, 0)
    loreFrame.body:SetWidth(LORE_TEXT_W)
    loreFrame.body:SetJustifyH("LEFT")
    loreFrame.body:SetWordWrap(true)
    loreFrame.body:SetSpacing(3)

    -- Wiki link at the bottom of the content
    loreFrame.wikiLabel = loreContent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    loreFrame.wikiLabel:SetPoint("TOPLEFT", loreFrame.body, "BOTTOMLEFT", 0, -12)
    loreFrame.wikiLabel:SetWidth(LORE_TEXT_W)
    loreFrame.wikiLabel:SetJustifyH("LEFT")
    loreFrame.wikiLabel:SetWordWrap(true)
    loreFrame.wikiLabel:SetTextColor(0.40, 0.73, 1.00)

    loreFrame.loreContent = loreContent

    -- Position next to the requirements panel
    if frame then
        loreFrame:SetPoint("TOPLEFT", frame, "TOPRIGHT", 4, 0)
    else
        loreFrame:SetPoint("CENTER")
    end

    loreFrame:Hide()
    return loreFrame
end

function Panel.ShowLore()
    BuildLoreFrame()

    local key = HCE_CharDB and HCE_CharDB.selectedCharacter
    local char = key and HCE.GetCharacter and HCE.GetCharacter(key) or nil
    if not char then return end

    -- Only core characters have lore
    if HCE.AdditionalCharacters and HCE.AdditionalCharacters[char.name] then return end

    local lore = HCE.LoreData and HCE.LoreData[char.name]
    if not lore or lore == "" then
        lore = "No lore entry found for this class."
    end

    local cc = classColor(char.class)
    loreFrame.titleText:SetText("|cff" .. cc .. char.name .. "|r — Lore")
    loreFrame.body:SetText(lore)

    -- Wiki link
    local slug = char.name:gsub(" ", "_")
    loreFrame.wikiLabel:SetText("Read more: https://warcraft.wiki.gg/wiki/" .. slug)

    -- Resize content to fit text
    local textH = loreFrame.body:GetStringHeight()
    local wikiH = loreFrame.wikiLabel:GetStringHeight()
    loreFrame.loreContent:SetHeight(textH + wikiH + 24)

    -- Reanchor next to the panel if it's shown
    if frame and frame:IsShown() then
        loreFrame:ClearAllPoints()
        loreFrame:SetPoint("TOPLEFT", frame, "TOPRIGHT", 4, 0)
    end

    loreFrame:Show()
end

function Panel.HideLore()
    if loreFrame then loreFrame:Hide() end
end

function Panel.ToggleLore()
    BuildLoreFrame()
    if loreFrame:IsShown() then
        Panel.HideLore()
    else
        Panel.ShowLore()
    end
end

----------------------------------------------------------------------
-- Show / hide / toggle
----------------------------------------------------------------------

function Panel.Show()
    BuildFrame()
    frame:Show()
    db().shown = true
    Panel.Refresh()
end

function Panel.Hide()
    if frame then frame:Hide() end
    db().shown = false
end

function Panel.Toggle()
    BuildFrame()
    if frame:IsShown() then Panel.Hide() else Panel.Show() end
end

function Panel.IsShown()
    return frame and frame:IsShown()
end

-- Expose under HCE so the main file's slash command can call it
HCE.TogglePanel  = Panel.Toggle
HCE.ShowPanel    = Panel.Show
HCE.HidePanel    = Panel.Hide
HCE.RefreshPanel = Panel.Refresh

----------------------------------------------------------------------
-- Minimap button
----------------------------------------------------------------------

local minimapButton

local function UpdateMinimapPos()
    if not minimapButton then return end
    local angle = db().minimap.angle or 215
    local rad = math.rad(angle)
    local radius = 80
    local x = math.cos(rad) * radius
    local y = math.sin(rad) * radius
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function BuildMinimapButton()
    if minimapButton then return minimapButton end

    minimapButton = CreateFrame("Button", "HCE_MinimapButton", Minimap)
    minimapButton:SetSize(32, 32)
    minimapButton:SetFrameStrata("MEDIUM")
    minimapButton:SetFrameLevel(8)
    minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    minimapButton:RegisterForDrag("LeftButton")
    minimapButton:SetMovable(true)

    -- Outer ring (reuses Blizzard's minimap tracking ring texture)
    local overlay = minimapButton:CreateTexture(nil, "OVERLAY")
    overlay:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    overlay:SetSize(54, 54)
    overlay:SetPoint("TOPLEFT", 0, 0)

    -- Background circle (gives the icon a consistent fill)
    local bg = minimapButton:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetSize(20, 20)
    bg:SetPoint("TOPLEFT", 7, -6)

    -- Custom icon drawn with plain textures — an angular gold chevron
    -- over a dark disc.  Keeps it visually distinct from stock addon
    -- buttons which are all Blizzard spell icons.
    local disc = minimapButton:CreateTexture(nil, "ARTWORK")
    disc:SetTexture("Interface\\Buttons\\WHITE8x8")
    disc:SetVertexColor(0.08, 0.08, 0.11, 1)
    disc:SetSize(18, 18)
    disc:SetPoint("TOPLEFT", 8, -7)

    local glyph = minimapButton:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    glyph:SetPoint("CENTER", disc, "CENTER", 0, 0)
    glyph:SetText("|cffe6b422H|r|cffffd100C|r")

    minimapButton:SetScript("OnClick", function(_, btn)
        if btn == "RightButton" then
            -- Right-click toggles the lock
            local s = db()
            s.locked = not s.locked
            Panel.UpdatePinIcon()
            HCE.Print(s.locked and "Requirements panel locked." or "Requirements panel unlocked.")
        else
            Panel.Toggle()
        end
    end)

    -- Drag-around-minimap support
    minimapButton:SetScript("OnDragStart", function(self)
        self:SetScript("OnUpdate", function()
            local mx, my = Minimap:GetCenter()
            local px, py = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            px, py = px / scale, py / scale
            local angle = math.deg(math.atan2(py - my, px - mx))
            db().minimap.angle = angle
            UpdateMinimapPos()
        end)
    end)
    minimapButton:SetScript("OnDragStop", function(self)
        self:SetScript("OnUpdate", nil)
    end)

    minimapButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("Hardcore Classes Enhanced")
        GameTooltip:AddLine("|cffffffffLeft-click|r toggle requirements panel", 1, 1, 1)
        GameTooltip:AddLine("|cffffffffRight-click|r lock/unlock panel", 1, 1, 1)
        GameTooltip:AddLine("|cffffffffDrag|r move this button", 1, 1, 1)
        GameTooltip:Show()
    end)
    minimapButton:SetScript("OnLeave", function() GameTooltip:Hide() end)

    UpdateMinimapPos()
    if db().minimap.hide then minimapButton:Hide() else minimapButton:Show() end
    return minimapButton
end

function Panel.ShowMinimapButton()
    BuildMinimapButton()
    db().minimap.hide = false
    minimapButton:Show()
end

function Panel.HideMinimapButton()
    db().minimap.hide = true
    if minimapButton then minimapButton:Hide() end
end

HCE.ShowMinimapButton = Panel.ShowMinimapButton
HCE.HideMinimapButton = Panel.HideMinimapButton

----------------------------------------------------------------------
-- Event hookup (for live refresh)
----------------------------------------------------------------------

local liveFrame = CreateFrame("Frame")
liveFrame:RegisterEvent("PLAYER_LOGIN")
liveFrame:RegisterEvent("PLAYER_LEVEL_UP")
liveFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
liveFrame:RegisterEvent("SKILL_LINES_CHANGED")
liveFrame:RegisterEvent("CHARACTER_POINTS_CHANGED")
liveFrame:RegisterEvent("UNIT_AURA")
liveFrame:RegisterEvent("UNIT_PET")
pcall(function() liveFrame:RegisterEvent("COMPANION_UPDATE") end)
liveFrame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
liveFrame:RegisterEvent("ZONE_CHANGED")
pcall(function() liveFrame:RegisterEvent("PLAYER_UPDATE_RESTING") end)
liveFrame:RegisterEvent("BAG_UPDATE")
liveFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_LOGIN" then
        -- Defer a tick so SavedVariables + CharacterData are ready
        C_Timer.After(1.2, function()
            BuildFrame()
            BuildMinimapButton()
            if db().shown then Panel.Show() end
            Panel.Refresh()
        end)
    elseif event == "PLAYER_LEVEL_UP" then
        -- Player level isn't updated until the next frame; defer.
        C_Timer.After(0.1, Panel.Refresh)
    elseif event == "PLAYER_EQUIPMENT_CHANGED" then
        -- EquipmentCheck.lua handles the actual check and calls
        -- RefreshPanel, but if it hasn't loaded yet we still refresh.
        C_Timer.After(0.5, Panel.Refresh)
    elseif event == "SKILL_LINES_CHANGED" then
        -- ProfessionCheck.lua handles the actual check and calls
        -- RefreshPanel, but we also refresh here as a fallback.
        C_Timer.After(0.5, Panel.Refresh)
    elseif event == "CHARACTER_POINTS_CHANGED" then
        -- TalentCheck.lua handles the actual check and calls
        -- RefreshPanel, but we also refresh here as a fallback.
        C_Timer.After(0.5, Panel.Refresh)
    elseif event == "UNIT_AURA" then
        local unit = ...
        if unit == "player" then
            -- SelfFoundCheck.lua handles the actual check and calls
            -- RefreshPanel, but we also refresh here as a fallback.
            C_Timer.After(0.5, Panel.Refresh)
        end
    elseif event == "UNIT_PET" then
        local unit = ...
        if unit == "player" then
            -- ChallengeCheck (Imp/No demon) reacts to pet changes.
            C_Timer.After(0.5, Panel.Refresh)
        end
    elseif event == "ZONE_CHANGED_NEW_AREA" then
        -- Homebound / zone-visit challenges react to zone changes.
        C_Timer.After(0.7, Panel.Refresh)
    elseif event == "ZONE_CHANGED" or event == "PLAYER_UPDATE_RESTING" then
        -- Nocturnal/Diurnal challenges react to entering/leaving rest areas.
        C_Timer.After(0.3, Panel.Refresh)
    elseif event == "BAG_UPDATE" then
        -- Bag contents changed -- refresh for herb pouch / consumable checks.
        C_Timer.After(0.6, Panel.Refresh)
    end
end)

-- Periodic timer for time-of-day challenges (Nocturnal/Diurnal).
-- Checks every 60 seconds so the panel updates when server hour changes.
C_Timer.NewTicker(60, function()
    if Panel.frame and Panel.frame:IsShown() then
        Panel.Refresh()
    end
end)
