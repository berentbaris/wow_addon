----------------------------------------------------------------------
-- HardcoreClassesEnhanced
-- Extra lore-based character classes for hardcore runs.
-- Tracks whether you're meeting your chosen character's requirements.
----------------------------------------------------------------------

-- Addon-wide namespace (CharacterData.lua loads first and may have
-- already created HCE, so we preserve it)
HCE = HCE or {}
HCE.version = "0.1.0"

----------------------------------------------------------------------
-- Saved variable defaults
----------------------------------------------------------------------
local GLOBAL_DEFAULTS = {
    alertsEnabled = true,
    forbiddenAlertsEnabled = true,
    chatWarningsEnabled = true,
    alertSoundEnabled = true,
    edgeFlashEnabled = true,
    gameplayTipsEnabled = true,
    partyAnnounce = true,
    welcomeShown = {},  -- keyed by "name-realm"
}

local CHAR_DEFAULTS = {
    selectedCharacter = nil,   -- string key into HCE.Characters
    manualOverride    = false, -- true if the player picked manually
    lastLevel         = nil,   -- highest level this char had last time we looked
                               -- (used by LevelAlert to detect crossed gates)
}

----------------------------------------------------------------------
-- Event frame
----------------------------------------------------------------------
local eventFrame = CreateFrame("Frame", "HCE_EventFrame", UIParent)

eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_LOGOUT")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")

----------------------------------------------------------------------
-- Saved-variable initialisation helpers
----------------------------------------------------------------------
local function InitDB(saved, defaults)
    if saved == nil then return CopyTable(defaults) end
    for k, v in pairs(defaults) do
        if saved[k] == nil then
            saved[k] = v
        end
    end
    return saved
end

----------------------------------------------------------------------
-- Chat helpers
----------------------------------------------------------------------
local CHAT_PREFIX = "|cff66bbff[HCE]|r "

function HCE.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage(CHAT_PREFIX .. tostring(msg))
end

----------------------------------------------------------------------
-- Character detection & assignment
----------------------------------------------------------------------

--- Try to auto-detect the player's enhanced class from race/class/gender.
--- If exactly one match, assign it automatically.
--- If multiple matches, list them and prompt for /hce pick.
--- If no match, inform the player.
local function TryAutoDetect()
    -- Skip if the player already chose manually
    if HCE_CharDB.manualOverride then return end
    -- Skip if already assigned from a previous session
    if HCE_CharDB.selectedCharacter then return end

    local matches = HCE.FindMatchingCharacters()

    if #matches == 1 then
        local char = matches[1]
        HCE_CharDB.selectedCharacter = char.name
        -- First-time selection: the player has already levelled up to
        -- their current level under no enhanced rules, so don't fire
        -- toasts retroactively for the climb to get here.
        HCE_CharDB.lastLevel = UnitLevel("player") or 1
        if HCE.DoubtSystem and HCE.DoubtSystem.OnClassChanged then HCE.DoubtSystem.OnClassChanged() end
        HCE.Print("Auto-detected your enhanced class: |cffffd100" .. char.name .. "|r (" .. char.spec .. " " .. char.class:sub(1,1) .. char.class:sub(2):lower() .. ")")
    else
        -- No match or multiple matches — open the catalog for the player's class
        if #matches == 0 then
            HCE.Print("No exact match found. Opening the class catalog…")
        else
            HCE.Print("Multiple enhanced classes match your character. Opening the catalog…")
        end
        HCE.Print("(Type |cffffd100/hce catalog|r to reopen it later.)")
        if HCE.CatalogUI and HCE.CatalogUI.ShowForPlayer then
            C_Timer.After(0.5, HCE.CatalogUI.ShowForPlayer)
        end
    end
end

----------------------------------------------------------------------
-- Welcome & status display
----------------------------------------------------------------------

function HCE.PrintWelcome()
    local _, classToken = UnitClass("player")
    local race   = UnitRace("player")
    local sex    = UnitSex("player")
    local name   = UnitName("player")
    local gender = (sex == 3) and "female" or "male"
    local class  = classToken:sub(1,1) .. classToken:sub(2):lower()

    if HCE_CharDB.selectedCharacter then
        local char = HCE.GetCharacter(HCE_CharDB.selectedCharacter)
        if char then
            HCE.Print("HCE loaded. Enhanced class: |cffffd100" .. char.name .. "|r")
            -- Show a quick summary using ProgressSummary as the source of truth
            local level = UnitLevel("player")
            local summary = HCE.Progress and HCE.Progress.Collect and HCE.Progress.Collect()
            if summary and summary.counts then
                local c = summary.counts
                local active = c.pass + c.fail + c.unchecked
                HCE.Print(active .. " requirement(s) active at level " .. level .. ". Click the minimap icon or type |cffffd100/hce status|r for details.")
            else
                HCE.Print("Click the minimap icon or type |cffffd100/hce status|r for details.")
            end
            -- Warn if the saved enhanced class doesn't match this character's WoW class
            if char.class ~= classToken then
                local expectedClass = char.class:sub(1,1) .. char.class:sub(2):lower()
                local displayName = HCE.GetCharDisplayName and HCE.GetCharDisplayName(char) or char.name
                HCE.Print("|cffff5555WARNING:|r Your saved enhanced class |cffffd100" .. displayName
                    .. "|r requires a |cffffd100" .. expectedClass .. "|r, but you are a |cffffd100" .. class
                    .. "|r! Use |cffffd100/hce reset|r to clear your selection.")
            end
        else
            HCE.Print("Enhanced class: |cffffd100" .. HCE_CharDB.selectedCharacter .. "|r (data not found — try |cffffd100/hce reset|r)")
        end
    else
        HCE.Print("No enhanced class selected. Type |cffffd100/hce catalog|r to choose one.")
    end
    HCE.Print("Type |cffffd100/hce catalog|r or |cffffd100/hce wiki|r to browse all enhanced classes.")
    HCE.Print("Join the HCE Discord Community by typing |cffffd100/hce join|r.")
    HCE.Print("Support the addon: |cff66bbffbuymeacoffee.com/berentbaris|r — or type |cffffd100/hce donate|r")
end

--- Print full requirement details for the selected character.
local function PrintFullStatus()
    if not HCE_CharDB.selectedCharacter then
        HCE.Print("No enhanced class selected. Type |cffffd100/hce pick|r to choose one.")
        return
    end
    local char = HCE.GetCharacter(HCE_CharDB.selectedCharacter)
    if not char then
        HCE.Print("Character data not found for \"" .. HCE_CharDB.selectedCharacter .. "\".")
        return
    end

    local level = UnitLevel("player")
    local class = char.class:sub(1,1) .. char.class:sub(2):lower()

    HCE.Print("--- " .. char.name .. " (" .. char.spec .. " " .. class .. ") ---")

    -- Race / gender / self-found
    local charSF
    if HCE.GetCharSelfFound then charSF = HCE.GetCharSelfFound(char) else charSF = char.selfFound end
    HCE.Print("Race: " .. char.race .. " | Gender: " .. char.gender .. " | Self-found: " .. (charSF and "Yes" or "No"))

    -- Professions
    if #char.professions > 0 then
        HCE.Print("Professions: " .. table.concat(char.professions, ", "))
    end

    -- Equipment
    if #char.equipment > 0 then
        HCE.Print("Equipment:")
        for _, eq in ipairs(char.equipment) do
            local tag = (level >= eq.level) and "|cff00ff00ACTIVE|r" or "|cff888888lv " .. eq.level .. "|r"
            HCE.Print("  " .. tag .. " " .. eq.desc)
        end
    end

    -- Challenges
    local activeChallenges = HCE.GetActiveChallenges and HCE.GetActiveChallenges(char) or char.challenges or {}
    if #activeChallenges > 0 then
        HCE.Print("Challenges:")
        for _, ch in ipairs(activeChallenges) do
            local tag = (level >= ch.level) and "|cff00ff00ACTIVE|r" or "|cff888888lv " .. ch.level .. "|r"
            local desc = ch.desc
            local extra = HCE.ChallengeDescriptions and HCE.ChallengeDescriptions[ch.desc]
            if extra then desc = desc .. " — " .. extra end
            HCE.Print("  " .. tag .. " " .. desc)
        end
    end

    -- Companion / pet / mount
    if char.companion then
        local tag = (level >= char.companion.level) and "|cff00ff00ACTIVE|r" or "|cff888888lv " .. char.companion.level .. "|r"
        HCE.Print("Companion: " .. tag .. " " .. char.companion.desc)
    end
    if char.pet then
        local tag = (level >= char.pet.level) and "|cff00ff00ACTIVE|r" or "|cff888888lv " .. char.pet.level .. "|r"
        HCE.Print("Hunter pet: " .. tag .. " " .. char.pet.desc)
    end
    if char.mount then
        local tag = (level >= char.mount.level) and "|cff00ff00ACTIVE|r" or "|cff888888lv " .. char.mount.level .. "|r"
        HCE.Print("Mount: " .. tag .. " " .. char.mount.desc)
    end

    -- Gameplay tips
    if char.gameplay then
        HCE.Print("Gameplay: " .. char.gameplay)
    end
end

----------------------------------------------------------------------
-- Slash commands
----------------------------------------------------------------------
SLASH_HCE1 = "/hce"
SLASH_HCE2 = "/hardcoreclasses"

SlashCmdList["HCE"] = function(msg)
    local cmd = strtrim(msg):lower()

    if cmd == "" or cmd == "help" then
        HCE.Print("Commands:")
        HCE.Print("  /hce            — show this help")
        HCE.Print("  /hce settings   — open the settings panel")
        HCE.Print("  /hce donate     — support the addon developer")
        HCE.Print("  /hce join     — join the HCE Discord Community")
        HCE.Print("  /hce wiki     — check out the addon wiki")
        HCE.Print("  /hce progress   — show progress checklist with completion %")
        HCE.Print("  /hce status     — show full requirement details")
        HCE.Print("  /hce ui         — open the character selection window")
        HCE.Print("  /hce pick       — open the class catalog")
        HCE.Print("  /hce pick <name>— pick a specific character by name (text)")
        HCE.Print("  /hce panel      — toggle the requirements panel")
        HCE.Print("  /hce minimap    — show/hide the minimap button")
        HCE.Print("  /hce alerts     — toggle level-up requirement toasts")
        HCE.Print("  /hce testalert  — preview a toast alert")
        HCE.Print("  /hce forbidden  — toggle forbidden-item alerts")
        HCE.Print("  /hce testforbidden — preview a forbidden-item alert")
        HCE.Print("  /hce testsummary — preview the level-up summary frame")
        HCE.Print("  /hce selffound  — check self-found / self-made status")
        HCE.Print("  /hce talents    — check talent/spec status")
        HCE.Print("  /hce professions— check profession status")
        HCE.Print("  /hce challenges — check challenge status")
        HCE.Print("  /hce zones      — check zone/continent tracking status")
        HCE.Print("  /hce companion  — check companion (vanity pet) status")
        HCE.Print("  /hce hunterpet  — check hunter pet species status")
        HCE.Print("  /hce mount      — check mount requirement status")
        HCE.Print("  /hce quests     — check quest completion progress")
        HCE.Print("  /hce behavioral — check behavioral challenge status (Drifter/Ephemeral)")
        HCE.Print("  /hce sources    — show item-source breakdown (vendor/quest/crafted)")
        HCE.Print("  /hce gameplay   — show expanded gameplay flavour tips")
        HCE.Print("  /hce tips       — toggle periodic gameplay tip reminders")
        HCE.Print("  /hce curated    — show curated item-ID list status")
        HCE.Print("  /hce list       — list all enhanced classes for your class")
        HCE.Print("  /hce reset      — clear your character selection")
        HCE.Print("  /hce doubt      — show current doubt level")
        HCE.Print("  /hce doubt reset— reset doubt for current class")
        HCE.Print("  /hce version    — show addon version")
        HCE.Print(" ")
        HCE.Print("|cffffd100Social:|r")
        HCE.Print("  /hce scan       — scan for other HCE players")
        HCE.Print("  /hce share <name> — whisper a player about HCE")
        HCE.Print("  /hce share party— share HCE info in party chat")
        HCE.Print("  /hce debug      — toggle comm debug messages")
        HCE.Print("  /hce status     — show comm channel diagnostics")

    elseif cmd == "status" then
        PrintFullStatus()

    elseif cmd == "panel" or cmd == "req" or cmd == "requirements" then
        if HCE.TogglePanel then
            HCE.TogglePanel()
        else
            HCE.Print("Requirements panel not loaded.")
        end

    elseif cmd == "testalert" or cmd == "test" then
        if HCE.TestAlert then
            HCE.TestAlert()
        else
            HCE.Print("Alert module not loaded.")
        end

    elseif cmd == "alerts" then
        HCE_GlobalDB.alertsEnabled = not HCE_GlobalDB.alertsEnabled
        if HCE_GlobalDB.alertsEnabled then
            HCE.Print("Level-up requirement toasts |cff00ff00enabled|r.")
        else
            HCE.Print("Level-up requirement toasts |cffff5555disabled|r.")
            if HCE.Alert then HCE.Alert.DismissAll() end
        end

    elseif cmd == "forbidden" then
        HCE_GlobalDB.forbiddenAlertsEnabled = not HCE_GlobalDB.forbiddenAlertsEnabled
        if HCE_GlobalDB.forbiddenAlertsEnabled then
            HCE.Print("Forbidden-item alerts |cff00ff00enabled|r.")
        else
            HCE.Print("Forbidden-item alerts |cffff5555disabled|r.")
            if HCE.ForbiddenAlert then HCE.ForbiddenAlert.DismissAll() end
        end

    elseif cmd == "testforbidden" then
        if HCE.TestForbiddenAlert then
            HCE.TestForbiddenAlert()
        else
            HCE.Print("Forbidden-alert module not loaded.")
        end

    elseif cmd == "minimap" then
        if HCE.ShowMinimapButton and HCE_GlobalDB and HCE_GlobalDB.panel then
            if HCE_GlobalDB.panel.minimap and HCE_GlobalDB.panel.minimap.hide then
                HCE.ShowMinimapButton()
                HCE.Print("Minimap button shown.")
            else
                HCE.HideMinimapButton()
                HCE.Print("Minimap button hidden. Use |cffffd100/hce minimap|r to bring it back.")
            end
        end

    elseif cmd == "ui" or cmd == "show" or cmd == "open" then
        if HCE.CatalogUI and HCE.CatalogUI.Show then
            HCE.CatalogUI.Show()
        else
            HCE.Print("Catalog UI not loaded.")
        end

    elseif cmd:sub(1, 4) == "pick" then
        local arg = strtrim(cmd:sub(5))
        if arg == "" then
            if HCE.CatalogUI and HCE.CatalogUI.ShowForPlayer then
                HCE.CatalogUI.ShowForPlayer()
            else
                HCE.Print("Catalog UI not loaded.")
            end
        else
            -- Try to find a character by name (case-insensitive partial match)
            local found = nil
            local argLower = arg:lower()
            for key, char in pairs(HCE.Characters) do
                if key:lower() == argLower or key:lower():find(argLower, 1, true) then
                    found = char
                    break
                end
            end
            if found then
                HCE_CharDB.selectedCharacter = found.name
                HCE_CharDB.manualOverride = true
                HCE.Print("Selected enhanced class: |cffffd100" .. found.name .. "|r (" .. found.spec .. ")")
                if HCE.ResyncLevelAlerts then HCE.ResyncLevelAlerts() end
                if HCE.ProfessionCheck and HCE.ProfessionCheck.ResetWarnings then HCE.ProfessionCheck.ResetWarnings() end
                if HCE.TalentCheck and HCE.TalentCheck.ResetWarnings then HCE.TalentCheck.ResetWarnings() end
                if HCE.SelfFoundCheck and HCE.SelfFoundCheck.ResetWarnings then HCE.SelfFoundCheck.ResetWarnings() end
                if HCE.ChallengeCheck and HCE.ChallengeCheck.ResetWarnings then HCE.ChallengeCheck.ResetWarnings() end
                if HCE.ZoneCheck and HCE.ZoneCheck.ResetTracking then HCE.ZoneCheck.ResetTracking() end
                if HCE.BehavioralCheck and HCE.BehavioralCheck.ResetTracking then HCE.BehavioralCheck.ResetTracking() end
                if HCE.CompanionCheck and HCE.CompanionCheck.ResetWarnings then HCE.CompanionCheck.ResetWarnings() end
                if HCE.HunterPetCheck and HCE.HunterPetCheck.ResetWarnings then HCE.HunterPetCheck.ResetWarnings() end
                if HCE.MountCheck and HCE.MountCheck.ResetWarnings then HCE.MountCheck.ResetWarnings() end
                -- Immediately run fresh checks so the panel has results
                if HCE.EquipmentCheck and HCE.EquipmentCheck.RunCheck then HCE.EquipmentCheck.RunCheck() end
                if HCE.CompanionCheck and HCE.CompanionCheck.RunCheck then HCE.CompanionCheck.RunCheck() end
                if HCE.HunterPetCheck and HCE.HunterPetCheck.RunCheck then HCE.HunterPetCheck.RunCheck() end
                if HCE.MountCheck and HCE.MountCheck.RunCheck then HCE.MountCheck.RunCheck() end
                if HCE.QuestCheck and HCE.QuestCheck.RunCheck then HCE.QuestCheck.RunCheck() end
                if HCE.DoubtSystem and HCE.DoubtSystem.OnClassChanged then HCE.DoubtSystem.OnClassChanged() end
                if HCE.RefreshPanel then HCE.RefreshPanel() end
            else
                HCE.Print("No enhanced class found matching \"" .. arg .. "\". Try |cffffd100/hce pick|r to see options.")
            end
        end

    elseif cmd == "list" or cmd == "catalog" or cmd == "catalogue" or cmd == "browse" then
        if HCE.CatalogUI and HCE.CatalogUI.Toggle then
            HCE.CatalogUI.Toggle()
        else
            HCE.Print("Catalog module not loaded.")
        end

    elseif cmd == "professions" or cmd == "prof" then
        if not HCE.ProfessionCheck then
            HCE.Print("Profession tracking module not loaded.")
        elseif not HCE_CharDB or not HCE_CharDB.selectedCharacter then
            HCE.Print("No enhanced class selected. Type |cffffd100/hce pick|r to choose one.")
        else
            local char = HCE.GetCharacter(HCE_CharDB.selectedCharacter)
            if not char or not char.professions or #char.professions == 0 then
                HCE.Print("Your enhanced class has no profession requirements.")
            else
                local results = HCE.ProfessionCheck.RunCheck()
                local level = UnitLevel("player") or 1
                HCE.Print("Profession status (level " .. level .. "):")
                for _, profName in ipairs(char.professions) do
                    local r = results[profName]
                    if r then
                        local tag
                        if r.status == "pass" then
                            tag = "|cff00ff00OK|r"
                        elseif r.status == "fail" then
                            tag = "|cffff5555BEHIND|r"
                        elseif r.status == "inactive" then
                            tag = "|cff888888inactive|r"
                        else
                            tag = "|cffffaa33???|r"
                        end
                        HCE.Print("  " .. profName .. ": " .. tag .. " — " .. (r.detail or ""))
                    else
                        HCE.Print("  " .. profName .. ": |cff888888no data|r")
                    end
                end
                -- Debug: dump raw skill lines
                HCE.Print("|cff888888--- Debug: raw skill lines ---|r")
                local n = GetNumSkillLines and GetNumSkillLines() or 0
                for i = 1, n do
                    local v = { GetSkillLineInfo(i) }
                    local parts = {}
                    for idx = 1, #v do
                        parts[idx] = tostring(v[idx])
                    end
                    HCE.Print("  [" .. i .. "] " .. table.concat(parts, " | "))
                end
            end
        end

    elseif cmd == "challenges" or cmd == "challenge" or cmd == "ch" then
        if HCE.ChallengeCheck and HCE.ChallengeCheck.PrintStatus then
            HCE.ChallengeCheck.PrintStatus()
        else
            HCE.Print("Challenge tracking module not loaded.")
        end

    elseif cmd == "zones" or cmd == "zone" or cmd == "homebound" then
        if HCE.ZoneCheck and HCE.ZoneCheck.PrintStatus then
            HCE.ZoneCheck.PrintStatus()
        else
            HCE.Print("Zone tracking module not loaded.")
        end

    elseif cmd == "selffound" or cmd == "selfmade" or cmd == "sf" then
        if HCE.SelfFoundCheck and HCE.SelfFoundCheck.PrintStatus then
            HCE.SelfFoundCheck.PrintStatus()
        else
            HCE.Print("Self-found tracking module not loaded.")
        end

    elseif cmd == "talents" or cmd == "talent" or cmd == "spec" then
        if HCE.TalentCheck and HCE.TalentCheck.PrintStatus then
            HCE.TalentCheck.PrintStatus()
        else
            HCE.Print("Talent tracking module not loaded.")
        end

    elseif cmd == "sources" or cmd == "source" or cmd == "itemsource" then
        if HCE.PrintItemSources then
            HCE.PrintItemSources()
        else
            HCE.Print("Item source data module not loaded.")
        end

    elseif cmd == "curated" then
        -- Diagnostic: show curated item-ID list status.  Sorted so the
        -- finished lists surface at the top.
        if not HCE.CuratedItems then
            HCE.Print("Curated item lists not loaded.")
        else
            local rows = {}
            for name, list in pairs(HCE.CuratedItems) do
                local n = 0
                for _ in pairs(list) do n = n + 1 end
                local complete = HCE.CuratedComplete and HCE.CuratedComplete[name]
                table.insert(rows, { name = name, count = n, complete = complete })
            end
            table.sort(rows, function(a, b)
                if a.count ~= b.count then return a.count > b.count end
                return a.name < b.name
            end)
            HCE.Print("Curated item lists:")
            local totalItems, doneLists, totalLists = 0, 0, #rows
            for _, r in ipairs(rows) do
                local tag
                if r.complete then
                    tag = "|cff00ff00done|r"
                    doneLists = doneLists + 1
                elseif r.count > 0 then
                    tag = "|cffffd100" .. r.count .. " item" .. (r.count == 1 and "" or "s") .. "|r"
                else
                    tag = "|cff888888empty|r"
                end
                HCE.Print("  " .. r.name .. ": " .. tag)
                totalItems = totalItems + r.count
            end
            HCE.Print(string.format(
                "Total: %d item%s across %d list%s (%d marked complete).",
                totalItems, totalItems == 1 and "" or "s",
                totalLists, totalLists == 1 and "" or "s",
                doneLists
            ))
        end

    elseif cmd == "reset" then
        HCE_CharDB.selectedCharacter = nil
        HCE_CharDB.manualOverride = false
        HCE_CharDB.selectedChallenge = nil
        HCE_CharDB.lastLevel = UnitLevel("player") or 1
        HCE.Print("Enhanced class selection cleared. Opening the catalog…")
        if HCE.ProfessionCheck and HCE.ProfessionCheck.ResetWarnings then HCE.ProfessionCheck.ResetWarnings() end
        if HCE.TalentCheck and HCE.TalentCheck.ResetWarnings then HCE.TalentCheck.ResetWarnings() end
        if HCE.SelfFoundCheck and HCE.SelfFoundCheck.ResetWarnings then HCE.SelfFoundCheck.ResetWarnings() end
        if HCE.ChallengeCheck and HCE.ChallengeCheck.ResetWarnings then HCE.ChallengeCheck.ResetWarnings() end
        if HCE.ZoneCheck and HCE.ZoneCheck.ResetTracking then HCE.ZoneCheck.ResetTracking() end
        if HCE.BehavioralCheck and HCE.BehavioralCheck.ResetTracking then HCE.BehavioralCheck.ResetTracking() end
        if HCE.CompanionCheck and HCE.CompanionCheck.ResetWarnings then HCE.CompanionCheck.ResetWarnings() end
        if HCE.HunterPetCheck and HCE.HunterPetCheck.ResetWarnings then HCE.HunterPetCheck.ResetWarnings() end
        if HCE.MountCheck and HCE.MountCheck.ResetWarnings then HCE.MountCheck.ResetWarnings() end
        if HCE.RefreshPanel then HCE.RefreshPanel() end
        -- Auto-open the catalog for the player's class
        if HCE.CatalogUI and HCE.CatalogUI.ShowForPlayer then
            C_Timer.After(0.3, HCE.CatalogUI.ShowForPlayer)
        end

    elseif cmd == "companion" or cmd == "pet" or cmd == "critter" then
        if HCE.CompanionCheck and HCE.CompanionCheck.PrintStatus then
            HCE.CompanionCheck.PrintStatus()
        else
            HCE.Print("Companion tracking module not loaded.")
        end

    elseif cmd == "hunterpet" or cmd == "hpet" then
        if HCE.HunterPetCheck and HCE.HunterPetCheck.PrintStatus then
            HCE.HunterPetCheck.PrintStatus()
        else
            HCE.Print("Hunter pet tracking module not loaded.")
        end

    elseif cmd == "mount" or cmd == "riding" then
        if HCE.MountCheck and HCE.MountCheck.PrintStatus then
            HCE.MountCheck.PrintStatus()
        else
            HCE.Print("Mount tracking module not loaded.")
        end

    elseif cmd == "quests" or cmd == "quest" then
        if HCE.QuestCheck and HCE.QuestCheck.PrintStatus then
            HCE.QuestCheck.PrintStatus()
        else
            HCE.Print("Quest tracking module not loaded.")
        end

    elseif cmd == "weapons" or cmd == "weapon" or cmd == "wpn" then
        if HCE.WeaponProficiencyCheck and HCE.WeaponProficiencyCheck.PrintStatus then
            HCE.WeaponProficiencyCheck.PrintStatus()
        else
            HCE.Print("Weapon proficiency module not loaded.")
        end

    elseif cmd == "behavioral" or cmd == "behaviour" or cmd == "behavior" then
        if HCE.BehavioralCheck and HCE.BehavioralCheck.PrintStatus then
            HCE.BehavioralCheck.PrintStatus()
        else
            HCE.Print("Behavioral tracking module not loaded.")
        end

    elseif cmd == "progress" or cmd == "prog" or cmd == "checklist" then
        if HCE.Progress and HCE.Progress.PrintStatus then
            HCE.Progress.PrintStatus()
        else
            HCE.Print("Progress summary module not loaded.")
        end

    elseif cmd == "donate" or cmd == "support" then
        HCE.Print("Thanks for your support!")
        HCE.Print("|cff66bbffhttps://buymeacoffee.com/berentbaris|r")
        -- Open an edit box so the player can copy the URL
        if not HCE._donateEditBox then
            local eb = CreateFrame("EditBox", "HCE_DonateEditBox", UIParent, "InputBoxTemplate")
            eb:SetSize(320, 28)
            eb:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
            eb:SetAutoFocus(true)
            eb:SetText("https://buymeacoffee.com/berentbaris")
            eb:HighlightText()
            eb:SetScript("OnEscapePressed", function(self) self:Hide() end)
            eb:SetScript("OnEnterPressed", function(self) self:Hide() end)
            eb:SetScript("OnEditFocusLost", function(self) self:Hide() end)
            HCE._donateEditBox = eb
        else
            HCE._donateEditBox:SetText("https://buymeacoffee.com/berentbaris")
            HCE._donateEditBox:Show()
            HCE._donateEditBox:HighlightText()
            HCE._donateEditBox:SetFocus()
        end

    elseif cmd == "join" or cmd == "discord" then
        HCE.Print("Welcome to the community!")
        HCE.Print("|cff66bbffhttps://discord.gg/YdNZkAsSFf|r")
        -- Open an edit box so the player can copy the URL
        if not HCE._donateJoinBox then
            local eb = CreateFrame("EditBox", "HCE_donateJoinBox", UIParent, "InputBoxTemplate")
            eb:SetSize(320, 28)
            eb:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
            eb:SetAutoFocus(true)
            eb:SetText("https://discord.gg/YdNZkAsSFf")
            eb:HighlightText()
            eb:SetScript("OnEscapePressed", function(self) self:Hide() end)
            eb:SetScript("OnEnterPressed", function(self) self:Hide() end)
            eb:SetScript("OnEditFocusLost", function(self) self:Hide() end)
            HCE._donateJoinBox = eb
        else
            HCE._donateJoinBox:SetText("https://discord.gg/YdNZkAsSFf")
            HCE._donateJoinBox:Show()
            HCE._donateJoinBox:HighlightText()
            HCE._donateJoinBox:SetFocus()
        end

    elseif cmd == "pole weaving" then
        HCE.Print("Check this Youtube video for detailed explanation")
        HCE.Print("|cff66bbffhttps://www.youtube.com/watch?v=-bxMMK2vS5s|r")
        -- Open an edit box so the player can copy the URL
        if not HCE._donateJoinBox then
            local eb = CreateFrame("EditBox", "HCE_donateJoinBox", UIParent, "InputBoxTemplate")
            eb:SetSize(320, 28)
            eb:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
            eb:SetAutoFocus(true)
            eb:SetText("https://www.youtube.com/watch?v=-bxMMK2vS5s")
            eb:HighlightText()
            eb:SetScript("OnEscapePressed", function(self) self:Hide() end)
            eb:SetScript("OnEnterPressed", function(self) self:Hide() end)
            eb:SetScript("OnEditFocusLost", function(self) self:Hide() end)
            HCE._donateJoinBox = eb
        else
            HCE._donateJoinBox:SetText("https://www.youtube.com/watch?v=-bxMMK2vS5s")
            HCE._donateJoinBox:Show()
            HCE._donateJoinBox:HighlightText()
            HCE._donateJoinBox:SetFocus()
        end

    elseif cmd == "wiki" then
        HCE.Print("|cff66bbffhttps://hce-wiki.polia.nl/|r")
        -- Open an edit box so the player can copy the URL
        if not HCE._donateJoinBox then
            local eb = CreateFrame("EditBox", "HCE_donateJoinBox", UIParent, "InputBoxTemplate")
            eb:SetSize(320, 28)
            eb:SetPoint("CENTER", UIParent, "CENTER", 0, 100)
            eb:SetAutoFocus(true)
            eb:SetText("https://hce-wiki.polia.nl/")
            eb:HighlightText()
            eb:SetScript("OnEscapePressed", function(self) self:Hide() end)
            eb:SetScript("OnEnterPressed", function(self) self:Hide() end)
            eb:SetScript("OnEditFocusLost", function(self) self:Hide() end)
            HCE._donateJoinBox = eb
        else
            HCE._donateJoinBox:SetText("https://hce-wiki.polia.nl/")
            HCE._donateJoinBox:Show()
            HCE._donateJoinBox:HighlightText()
            HCE._donateJoinBox:SetFocus()
        end

    elseif cmd == "settings" or cmd == "options" or cmd == "config" then
        if HCE.SettingsPanel and HCE.SettingsPanel.Toggle then
            HCE.SettingsPanel.Toggle()
        else
            HCE.Print("Settings panel not loaded.")
        end

    elseif cmd == "gameplay" or cmd == "tips" or cmd == "flavor" then
        if cmd == "tips" and HCE.GameplayTips then
            -- Toggle periodic tip reminders
            if HCE_GlobalDB.gameplayTipsEnabled == nil then
                HCE_GlobalDB.gameplayTipsEnabled = true
            end
            HCE_GlobalDB.gameplayTipsEnabled = not HCE_GlobalDB.gameplayTipsEnabled
            if HCE_GlobalDB.gameplayTipsEnabled then
                HCE.Print("Periodic gameplay tip reminders |cff00ff00enabled|r.")
                HCE.GameplayTips.StartReminder()
            else
                HCE.Print("Periodic gameplay tip reminders |cffff5555disabled|r.")
                HCE.GameplayTips.StopReminder()
            end
        elseif HCE.GameplayTips and HCE.GameplayTips.PrintStatus then
            HCE.GameplayTips.PrintStatus()
        else
            HCE.Print("Gameplay tips module not loaded.")
        end

    elseif cmd == "testsummary" then
        if HCE.LevelUpSummary and HCE.LevelUpSummary.Test then
            HCE.LevelUpSummary.Test()
        else
            HCE.Print("Level-up summary module not loaded.")
        end

    elseif cmd:sub(1, 5) == "doubt" then
        local doubtArg = strtrim(cmd:sub(6)):lower()
        if doubtArg == "reset" then
            if HCE.DoubtSystem and HCE.DoubtSystem.ResetDoubt then
                HCE.DoubtSystem.ResetDoubt()
            else
                HCE.Print("Doubt system not loaded.")
            end
        elseif doubtArg:sub(1, 3) == "set" then
            local val = tonumber(strtrim(doubtArg:sub(4)))
            if val and HCE.DoubtSystem then
                HCE.DoubtSystem.SetDoubt(val)
                HCE.Print(string.format("Doubt set to %.1f%%", val))
            else
                HCE.Print("Usage: /hce doubt set <0-100>")
            end
        elseif doubtArg == "" then
            -- Show current doubt
            if HCE.DoubtSystem then
                local val = HCE.DoubtSystem.GetDoubt()
                HCE.Print(string.format("Current doubt: %.1f%%", val))
            else
                HCE.Print("Doubt system not loaded.")
            end
        else
            HCE.Print("Usage: /hce doubt — show doubt | /hce doubt set <0-100> | /hce doubt reset")
        end

    elseif cmd == "version" then
        HCE.Print("Version " .. HCE.version)

    elseif cmd == "scan" then
        if HCE.AddonComm and HCE.AddonComm.StartNearbyScan then
            HCE.AddonComm.StartNearbyScan()
        else
            HCE.Print("Addon communication module not loaded.")
        end

    elseif cmd == "debug" then
        if HCE.AddonComm and HCE.AddonComm.ToggleDebug then
            HCE.AddonComm.ToggleDebug()
        end

    elseif cmd == "status" then
        if HCE.AddonComm and HCE.AddonComm.PrintStatus then
            HCE.AddonComm.PrintStatus()
        end

    elseif cmd:sub(1, 5) == "share" then
        local arg = strtrim(cmd:sub(6))

        -- Build class name and progress info
        local className = ""
        local progressLine = ""
        if HCE_CharDB and HCE_CharDB.selectedCharacter then
            local char = HCE.GetCharacter and HCE.GetCharacter(HCE_CharDB.selectedCharacter)
            if char then
                className = HCE.GetCharDisplayName and HCE.GetCharDisplayName(char) or char.name
            end
            if HCE.Progress and HCE.Progress.Collect and HCE.Progress.Percentage and HCE.Progress.GetRank then
                local summary = HCE.Progress.Collect()
                if summary and summary.counts then
                    local pct = HCE.Progress.Percentage(summary.counts)
                    local rank = HCE.Progress.GetRank(pct)
                    progressLine = " I'm at " .. math.floor(pct) .. "% progress towards becoming a Master " .. className .. "."
                end
            end
        end

        local msg1 = "I'm using Hardcore Classes Enhanced, an addon that adds 30+ lore-based classes to WoW Classic with unique challenges, requirements, and a rank system."
        local msg2
        if className ~= "" then
            msg2 = progressLine .. " Check it out on CurseForge!"
        else
            msg2 = "Check it out on CurseForge!"
        end

        if arg == "party" then
            if not IsInGroup or not IsInGroup() then
                HCE.Print("You are not in a party.")
                return
            end
            SendChatMessage(msg1, "PARTY")
            SendChatMessage(msg2, "PARTY")
            HCE.Print("Shared HCE info with your party!")
        else
            -- Determine whisper target: argument name, or current target
            local whisperTarget
            if arg ~= "" then
                whisperTarget = arg:sub(1,1):upper() .. arg:sub(2):lower()
            else
                local targetName = UnitName("target")
                if targetName and UnitIsPlayer("target") then
                    whisperTarget = targetName
                end
            end

            if not whisperTarget then
                HCE.Print("Usage: |cffffd100/hce share <name>|r or target a player.")
                HCE.Print("  |cffffd100/hce share party|r to share in party chat.")
                return
            end

            local myName = UnitName("player")
            if whisperTarget == myName then
                HCE.Print("You can't share with yourself!")
                return
            end

            SendChatMessage(msg1, "WHISPER", nil, whisperTarget)
            SendChatMessage(msg2, "WHISPER", nil, whisperTarget)
            HCE.Print("Shared HCE info with |cffffd100" .. whisperTarget .. "|r!")
        end

    elseif cmd == "debugtooltip" then
        if HCE.SelfFoundCheck and HCE.SelfFoundCheck.DebugTooltips then
            HCE.SelfFoundCheck.DebugTooltips()
        else
            HCE.Print("SelfFoundCheck module not loaded.")
        end

    else
        HCE.Print("Unknown command: " .. cmd .. ". Type /hce for help.")
    end
end

----------------------------------------------------------------------
-- Party chat announcements
--
-- Sends messages to PARTY chat so groupmates know you're playing
-- an enhanced class.  Controlled by HCE_GlobalDB.partyAnnounce.
----------------------------------------------------------------------

--- Check whether the player is in a party/raid.
--- Named HCE_IsInGroup to avoid shadowing the WoW API IsInGroup().
local function HCE_IsInGroup()
    if IsInGroup then return IsInGroup() end
    return (GetNumGroupMembers or GetNumPartyMembers or function() return 0 end)() > 0
end

--- Get the selected character data, or nil.
local function GetSelectedChar()
    if not HCE_CharDB or not HCE_CharDB.selectedCharacter then return nil end
    return HCE.GetCharacter and HCE.GetCharacter(HCE_CharDB.selectedCharacter)
end

--- Group-join announcement to party chat.
--- Waits until at least one other member is actually in the group
--- (not just invited), retrying a few times with a delay.
local function AnnounceGroupJoin(retries)
    retries = retries or 0
    if not HCE_GlobalDB.partyAnnounce then return end
    if not HCE_IsInGroup() then return end

    -- GetNumGroupMembers counts actual members (not pending invites).
    -- Right after sending an invite the count is 1 (just us).
    local count = (GetNumGroupMembers or GetNumPartyMembers or function() return 0 end)()
    if count < 2 then
        if retries < 10 then
            C_Timer.After(2.0, function() AnnounceGroupJoin(retries + 1) end)
        end
        return
    end

    local char = GetSelectedChar()
    if not char then return end

    local displayName = HCE.GetCharDisplayName and HCE.GetCharDisplayName(char) or char.name
    local msg = "[HCE] Beware! I’m playing as a " .. displayName
        .. " - a lore-based sub-optimal build with special rules."

    SendChatMessage(msg, "PARTY")
end

----------------------------------------------------------------------
-- Main event handler
----------------------------------------------------------------------
eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon == "HardcoreClassesEnhanced" then
            HCE_GlobalDB = InitDB(HCE_GlobalDB, GLOBAL_DEFAULTS)
            HCE_CharDB   = InitDB(HCE_CharDB, CHAR_DEFAULTS)
        end

    elseif event == "PLAYER_LOGIN" then
        -- Snapshot current group state so a /reload while already grouped
        -- doesn't trigger a false "just joined" announcement.
        HCE._wasInGroup = HCE_IsInGroup()
        C_Timer.After(1.0, function()
            TryAutoDetect()
            HCE.PrintWelcome()
        end)

    elseif event == "GROUP_ROSTER_UPDATE" then
        -- Only announce once when we transition from solo -> grouped,
        -- not on every roster change (someone joins/leaves/role changes).
        local inGroup = HCE_IsInGroup()
        if inGroup and not HCE._wasInGroup then
            -- Just joined a group — announce after a short delay
            HCE._wasInGroup = true  -- set immediately to prevent double-fire
            C_Timer.After(2.0, function()
                AnnounceGroupJoin()
            end)
        elseif not inGroup then
            HCE._wasInGroup = false
        end

    elseif event == "PLAYER_LOGOUT" then
        -- Future: persist runtime state
    end
end)
